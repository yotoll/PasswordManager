package edu.fsu.cs.mobile.passwordmanagement;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddUserFragment extends Fragment {
    public Button button;
    public EditText uname, pword, confirm;
    public AddUserFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_add_user, container, false);

        button = v.findViewById(R.id.add_add_user);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addNewUser();
            }
        });
        return v;
    }

    public void addNewUser() {

        uname= getView().findViewById(R.id.user_input);
        pword = getView().findViewById(R.id.pass_input);
        confirm = getView().findViewById(R.id.pass_confirm);
        if (uname.getText().toString().trim().equals("")) {
            Toast.makeText(getContext(), "Username invalid", Toast.LENGTH_SHORT).show();
        }
        //else if uname exists in database
        else if (pword.getText().toString().trim().equals("")) {
            Toast.makeText(getContext(), "Password invalid", Toast.LENGTH_SHORT).show();
        } else if (confirm.getText().toString().trim().equals("")) {
            Toast.makeText(getContext(), "Confirm Password invalid", Toast.LENGTH_SHORT).show();
        } else if (!pword.getText().toString().equals(confirm.getText().toString())) {
            Toast.makeText(getContext(), "Password and Confirm Password do not match", Toast.LENGTH_SHORT).show();
        } else {
            FragmentManager fm = getFragmentManager();
            UserFragment uf = new UserFragment();
            fm.beginTransaction().replace(R.id.frame, uf).commit();
        }
    }
}
