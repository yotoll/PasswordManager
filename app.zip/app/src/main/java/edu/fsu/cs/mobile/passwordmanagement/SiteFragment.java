package edu.fsu.cs.mobile.passwordmanagement;

import android.content.Context;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class SiteFragment extends ListFragment {

    public ArrayList<String> sites;
    public ArrayAdapter<String> adapt;
    public Button addsite;

    public SiteFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_site, container, false);

        sites = new ArrayList<String>();
        sites.add("Netflix");
        sites.add("Hulu");
        sites.add("Neopets");
        adapt = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1,sites);
        setListAdapter(adapt);

        addsite = v.findViewById(R.id.add_site);

        addsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("SiteFragment","Clicked!");
            }
        });

        return v;
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id)
    {
        super.onListItemClick(l, v, position, id);

        //Bundle up user name

        FragmentManager fm = getFragmentManager();
        UserFragment user = new UserFragment();
        fm.beginTransaction().replace(R.id.frame,user).commit();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
