package edu.fsu.cs.mobile.passwordmanagement;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Set;

public class SiteFragment extends ListFragment {

    public ArrayList<String> sites;
    public ArrayAdapter<String> adapt;
    public HashMap<String, HashMap<String,String>> entries;

    public SiteFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_site, container, false);

        //Preloaded entries for testing purposes
        entries = new HashMap<>();
        HashMap<String,String> netuser = new HashMap<>();
        netuser.put("Bob","ilikejokes");
        netuser.put("huehuehue","funnyjoke");
        netuser.put("potatojoe","jsfionugij93084");
        entries.put("Netflix",netuser);

        HashMap<String, String> hulusers = new HashMap<>();
        hulusers.put("honolulu","123explode!");
        hulusers.put("nil","henlo");

        entries.put("Hulu",hulusers);

        Set<String> s = entries.keySet();


        sites = new ArrayList<>();
        sites.addAll(s);
        adapt = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_list_item_1,sites);
        setListAdapter(adapt);

        return v;
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id)
    {
        super.onListItemClick(l, v, position, id);

        //Bundle up usernames and key
        FragmentManager fm = getFragmentManager();
        UserFragment user = new UserFragment();
        Bundle bee = new Bundle();
        String s = l.getItemAtPosition(position).toString();
        bee.putString("Site",s);
        bee.putSerializable("Users",entries.get(s));
        user.setArguments(bee);

        fm.beginTransaction().replace(R.id.frame,user).commit();
    }
}
