package edu.fsu.cs.mobile.passwordmanagement;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;


public class UserFragment extends ListFragment {

    public HashMap<String,String> users;
    public ArrayAdapter adapt;
    public Button addusr;
    public TextView title;
    public Bundle bee;
    public ArrayList<String> list;


    public UserFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_user, container, false);
        users = new HashMap<>();

        bee = new Bundle();
        bee = getArguments();

        if(bee!=null)
        {
            //grab arguments
            title = v.findViewById(R.id.site_title);
            title.setText(bee.getString("Site"));
            if(bee.containsKey("Users"))
            {
                users = (HashMap<String, String>) bee.getSerializable("Users");
                list = new ArrayList<>();
                list.addAll(users.keySet());
            }
            else
                list.add("No users found");

            if(bee.containsKey("UName"))
            {
                users.put(bee.getString("UName"),bee.getString("Pass"));
                Log.i("UserFragment","contains UName");
                list.add(bee.getString("UName"));
            }
        }
        else
        {
            list.add("No users found");
        }

        adapt = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_list_item_1,list);
        setListAdapter(adapt);

        addusr = v.findViewById(R.id.add_user);
        addusr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addUser();
            }
        });


        return v;
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id)
    {
        super.onListItemClick(l, v, position, id);
        FragmentManager fm = getFragmentManager();
        DetailsFragment user = new DetailsFragment();
        String s = l.getItemAtPosition(position).toString();
        bee.putString("UName",s);
        user.setArguments(bee);
        fm.beginTransaction().replace(R.id.frame,user).commit();
    }

    public void addUser()
    {
        FragmentManager fm = getFragmentManager();
        AddUserFragment auf = new AddUserFragment();
        auf.setArguments(bee);
        fm.beginTransaction().replace(R.id.frame,auf).commit();
    }
}
