package edu.fsu.cs.mobile.passwordmanagement;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class UserFragment extends ListFragment {

    public ArrayList<String> users;
    public ArrayAdapter adapt;
    public Button addusr,deletesite,editsite;


    public UserFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_user, container, false);
        users = new ArrayList<String>();
        users.add("nobody");
        users.add("testing");
        users.add("example");
        adapt = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1,users);
        setListAdapter(adapt);

        addusr = v.findViewById(R.id.add_user);
        addusr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addUser();
            }
        });

        editsite = v.findViewById(R.id.edit_site);
        editsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        deletesite = v.findViewById(R.id.delete_site);
        deletesite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });


        return v;
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id)
    {
        super.onListItemClick(l, v, position, id);
        FragmentManager fm = getFragmentManager();
        DetailsFragment user = new DetailsFragment();
        fm.beginTransaction().replace(R.id.frame,user).commit();
    }

    public void addUser()
    {
        FragmentManager fm = getFragmentManager();
        AddUserFragment auf = new AddUserFragment();
        fm.beginTransaction().replace(R.id.frame,auf).commit();
    }
}
