package edu.fsu.cs.mobile.passwordmanagement;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailsFragment extends Fragment {

    public Button editusr, deleteusr;
    public TextView usrname,pword;
    public Bundle bee;

    public DetailsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_details, container, false);

        //Get bundle
        //Perform query for user/pass
        //Display info
        bee = getArguments();

        usrname = v.findViewById(R.id.user_entry);
        usrname.setText(bee.getString("UName"));

        HashMap<String,String> search =(HashMap<String, String>) bee.getSerializable("Users");
        pword = v.findViewById(R.id.pass_entry);
        pword.setText(search.get(bee.getString("UName")));

        editusr = v.findViewById(R.id.edit_user);
        editusr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        deleteusr = v.findViewById(R.id.delete_user);

        deleteusr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteUser();
            }
        });

        return v;
    }

    public void deleteUser()
    {
        HashMap<String,String> old = (HashMap<String, String>) bee.getSerializable("Users");
        old.remove(bee.getString("UName"));
        Bundle newbee = new Bundle();

        newbee.putSerializable("Users",old);
        newbee.putString("Site",bee.getString("Site"));

        FragmentManager fm = getFragmentManager();
        UserFragment uf = new UserFragment();
        uf.setArguments(newbee);
        fm.beginTransaction().replace(R.id.frame,uf).commit();
    }

}
